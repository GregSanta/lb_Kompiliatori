﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kompilatorir
{
    public partial class Form1 : Form
    {
        string filePath ="";
        public Form1()
        {
            InitializeComponent();
        }



        void Form1_Load(object sender, EventArgs e)
        {
            WriteBox.Clear();
            openFileDialog1.FileName = @"data\Text2.txt";
            openFileDialog1.Filter =
                     "Текстовые файлы (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.Filter =
                     "Текстовые файлы (*.txt)|*.txt|All files (*.*)|*.*";
        }



        void CreateNew_Click(object sender, EventArgs e)
        {
            SaveFunc();
            WriteBox.Text = "";
            //сделать отчистку infoBox, если потребуется.
            saveFileDialog1.Title = "Введите имя нового файла:";
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All filters(*.*)|*.*";
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            filePath = saveFileDialog1.FileName;
        }

        void SaveAss_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                if (saveFileDialog1.FileName != "")
                    filePath = saveFileDialog1.FileName;
                using (StreamWriter sr = new StreamWriter(filePath))
                {
                    sr.WriteLine(WriteBox.Text);
                }
            }
        }

        void Open_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                if (openFileDialog1.FileName != "")
                    filePath = openFileDialog1.FileName;
                using (StreamReader sr = new StreamReader(filePath))
                {
                    WriteBox.Text = sr.ReadToEnd();
                }
            }
            
        }

         void Save_Click(object sender, EventArgs e)
        {
            SaveFunc();
        }

         void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        void SaveFunc()
        {
            if (filePath != "")
                System.IO.File.WriteAllText(filePath, WriteBox.Text);
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            WriteBox.Undo();
        }

        private void Repeat_Click(object sender, EventArgs e)
        {
            WriteBox.Redo();
        }

        void Cut_Click(object sender, EventArgs e)
        {
            WriteBox.Cut();
        }
        private void Copy_Click(object sender, EventArgs e)
        {
            WriteBox.Copy();
        }

        private void Input_Click(object sender, EventArgs e)
        {
            WriteBox.Paste();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            WriteBox.SelectedText = "";
        }

        private void SelectAll_Click(object sender, EventArgs e)
        {
            WriteBox.SelectAll();
        }

        private void CreateNewButton_Click(object sender, EventArgs e)
        {
            CreateNew_Click(sender, e);
        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            Open_Click(sender, e);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveAss_Click(sender, e);
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Cancel_Click(sender, e);
        }

        private void ForwardButton_Click(object sender, EventArgs e)
        {
            Repeat_Click(sender,e);
        }

        private void CopyButton_Click(object sender, EventArgs e)
        {
            Copy_Click(sender,e);
        }

        private void CutButton_Click(object sender, EventArgs e)
        {
            Cut_Click(sender, e);
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            Input_Click(sender, e);
        }

        private void ВызовСправкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:/Users/User.DESKTOP-Q2FT676/source/repos/Kompilatorir/About.html");
        }

        private void ОПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:/Users/User.DESKTOP-Q2FT676/source/repos/Kompilatorir/Who.html");
        }
    }
}
